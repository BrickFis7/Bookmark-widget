package com.example.bookmarkgrid

import android.content.Context
import android.content.Intent
import android.view.View
import android.widget.RemoteViews
import android.widget.RemoteViewsService

class GridService : RemoteViewsService() {

    override fun onGetViewFactory(intent: Intent): RemoteViewsService.RemoteViewsFactory =
        Factory(applicationContext)

    private class Factory(private val ctx: Context) : RemoteViewsService.RemoteViewsFactory {
        private var items: List<Bookmark> = emptyList()
        private var labels = false

        override fun onCreate() {
            onDataSetChanged()
        }

        override fun onDataSetChanged() {
            items = Store.load(ctx)
            labels = Store.labels(ctx)
        }

        override fun onDestroy() {}

        override fun getCount(): Int = items.size

        override fun getViewAt(position: Int): RemoteViews {
            val rv = RemoteViews(ctx.packageName, R.layout.widget_item)
            val b = items.getOrNull(position) ?: return rv
            rv.setImageViewBitmap(R.id.icon, IconRenderer.render(ctx, b, 128))
            rv.setTextViewText(R.id.label, b.title)
            rv.setViewVisibility(R.id.label, if (labels) View.VISIBLE else View.GONE)
            rv.setOnClickFillInIntent(
                R.id.item_root,
                Intent().putExtra(LaunchActivity.EXTRA_URL, b.url)
            )
            return rv
        }

        override fun getLoadingView(): RemoteViews? = null
        override fun getViewTypeCount(): Int = 1
        override fun getItemId(position: Int): Long = position.toLong()
        override fun hasStableIds(): Boolean = false
    }
}
