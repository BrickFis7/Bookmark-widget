package com.example.bookmarkgrid

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.text.TextUtils
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.util.UUID

class MainActivity : Activity() {

    private lateinit var listBox: LinearLayout
    private lateinit var browserBtn: Button
    private var pendingBitmap: Bitmap? = null
    private var resetIcon = false
    private var previewView: ImageView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val scroll = ScrollView(this)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(16), dp(12), dp(16), dp(32))
        scroll.addView(col)

        col.addView(tv("Add the widget: long-press your home screen, tap Widgets, pick Bookmark Grid. Resize it by long-pressing the widget.", 13f).apply { alpha = 0.7f })

        col.addView(tv("Bookmarks", 20f, true).apply { setPadding(0, dp(20), 0, dp(4)) })
        listBox = LinearLayout(this)
        listBox.orientation = LinearLayout.VERTICAL
        col.addView(listBox)
        col.addView(Button(this).apply {
            text = "+ Add bookmark"
            setOnClickListener { showEditDialog(null) }
        })

        col.addView(tv("Settings", 20f, true).apply { setPadding(0, dp(28), 0, dp(4)) })
        col.addView(tv("Open links with", 14f))
        browserBtn = Button(this)
        browserBtn.setOnClickListener { pickBrowser() }
        col.addView(browserBtn)
        col.addView(Switch(this).apply {
            text = "Show names under icons"
            isChecked = Store.labels(this@MainActivity)
            setPadding(0, dp(8), 0, dp(8))
            setOnCheckedChangeListener { _, checked ->
                Store.setLabels(this@MainActivity, checked)
                BookmarkWidget.refresh(this@MainActivity)
            }
        })
        col.addView(Button(this).apply {
            text = "Refresh website icons"
            setOnClickListener { refreshIcons() }
        })

        setContentView(scroll)
        refreshBrowserLabel()
        refreshList()
    }

    // ---------- list ----------

    private fun refreshList() {
        listBox.removeAllViews()
        val items = Store.load(this)
        if (items.isEmpty()) {
            listBox.addView(tv("No bookmarks yet.", 14f).apply {
                alpha = 0.6f
                setPadding(0, dp(8), 0, dp(8))
            })
        }
        items.forEachIndexed { i, b ->
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(0, dp(6), 0, dp(6))
            row.setOnClickListener { showEditDialog(b) }

            val img = ImageView(this)
            img.setImageBitmap(IconRenderer.render(this, b, 96))
            img.layoutParams = LinearLayout.LayoutParams(dp(44), dp(44))

            val texts = LinearLayout(this)
            texts.orientation = LinearLayout.VERTICAL
            texts.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            texts.setPadding(dp(12), 0, dp(4), 0)
            texts.addView(tv(b.title, 16f, true).apply {
                setSingleLine()
                ellipsize = TextUtils.TruncateAt.END
            })
            texts.addView(tv(b.url, 12f).apply {
                alpha = 0.6f
                setSingleLine()
                ellipsize = TextUtils.TruncateAt.END
            })

            row.addView(img)
            row.addView(texts)
            row.addView(smallButton("▲", i > 0) { move(i, -1) })
            row.addView(smallButton("▼", i < items.size - 1) { move(i, 1) })
            row.addView(smallButton("✕", true) { confirmDelete(b) })
            listBox.addView(row)
        }
    }

    private fun move(i: Int, d: Int) {
        val items = Store.load(this)
        val j = i + d
        if (j !in items.indices) return
        val t = items[i]
        items[i] = items[j]
        items[j] = t
        Store.save(this, items)
        refreshList()
        BookmarkWidget.refresh(this)
    }

    private fun confirmDelete(b: Bookmark) {
        AlertDialog.Builder(this)
            .setTitle("Delete \"${b.title}\"?")
            .setPositiveButton("Delete") { _, _ ->
                val items = Store.load(this)
                items.removeAll { it.id == b.id }
                Store.save(this, items)
                Store.iconFile(this, b.id).delete()
                refreshList()
                BookmarkWidget.refresh(this)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ---------- add / edit ----------

    private fun showEditDialog(existing: Bookmark?) {
        pendingBitmap = null
        resetIcon = false

        val form = LinearLayout(this)
        form.orientation = LinearLayout.VERTICAL
        form.setPadding(dp(20), dp(8), dp(20), 0)

        val nameEt = EditText(this).apply {
            hint = "Name"
            setSingleLine()
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_WORDS
            setText(existing?.title ?: "")
        }
        val urlEt = EditText(this).apply {
            hint = "Website, e.g. example.com"
            setSingleLine()
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            setText(existing?.url ?: "")
        }
        val preview = ImageView(this)
        val lp = LinearLayout.LayoutParams(dp(64), dp(64))
        lp.topMargin = dp(12)
        preview.layoutParams = lp
        preview.setImageBitmap(IconRenderer.render(this, existing ?: Bookmark("new", "?", "", false), 128))
        previewView = preview

        val pickBtn = Button(this).apply {
            text = "Choose my own image"
            setOnClickListener {
                val i = Intent(Intent.ACTION_GET_CONTENT)
                i.type = "image/*"
                startActivityForResult(i, REQ_PICK)
            }
        }
        val resetBtn = Button(this).apply {
            text = "Use website icon"
            setOnClickListener {
                pendingBitmap = null
                resetIcon = true
                preview.setImageBitmap(
                    IconRenderer.render(
                        this@MainActivity,
                        Bookmark("new", nameEt.text.toString().ifBlank { "?" }, "", false),
                        128
                    )
                )
                Toast.makeText(this@MainActivity, "Website icon will be fetched when you save", Toast.LENGTH_SHORT).show()
            }
        }

        form.addView(nameEt)
        form.addView(urlEt)
        form.addView(preview)
        form.addView(pickBtn)
        form.addView(resetBtn)

        val dlg = AlertDialog.Builder(this)
            .setTitle(if (existing == null) "Add bookmark" else "Edit bookmark")
            .setView(form)
            .setPositiveButton("Save", null)
            .setNegativeButton("Cancel", null)
            .create()
        dlg.setOnShowListener {
            dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val raw = urlEt.text.toString().trim()
                if (raw.isEmpty()) {
                    urlEt.error = "Enter a website"
                } else {
                    saveBookmark(existing, nameEt.text.toString().trim(), normalizeUrl(raw))
                    dlg.dismiss()
                }
            }
        }
        dlg.setOnDismissListener { previewView = null }
        dlg.show()
    }

    private fun saveBookmark(existing: Bookmark?, titleIn: String, url: String) {
        val host = hostOf(url)
        val title = titleIn.ifBlank { host?.removePrefix("www.") ?: url }
        val items = Store.load(this)
        val found = if (existing != null) items.firstOrNull { it.id == existing.id } else null
        val target = found ?: Bookmark(UUID.randomUUID().toString(), title, url, false).also { items.add(it) }
        val oldUrl = found?.url ?: ""
        target.title = title
        target.url = url

        val file = Store.iconFile(this, target.id)
        var fetch = false
        val pb = pendingBitmap
        if (pb != null) {
            Store.writePng(file, pb)
            target.custom = true
        } else if (resetIcon) {
            file.delete()
            target.custom = false
            fetch = true
        } else if (!target.custom && (oldUrl != url || !file.exists())) {
            fetch = true
        }

        Store.save(this, items)
        pendingBitmap = null
        resetIcon = false
        refreshList()
        BookmarkWidget.refresh(this)
        if (fetch) fetchIconAsync(target.id, host)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_PICK && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            val bmp = try { decodeSquare(uri) } catch (e: Exception) { null }
            if (bmp == null) {
                Toast.makeText(this, "Could not read that image", Toast.LENGTH_SHORT).show()
                return
            }
            pendingBitmap = bmp
            resetIcon = false
            previewView?.setImageBitmap(bmp)
        }
    }

    private fun decodeSquare(uri: Uri): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (bounds.outWidth / sample > 1024 || bounds.outHeight / sample > 1024) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val raw = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
            ?: return null
        val side = minOf(raw.width, raw.height)
        val square = Bitmap.createBitmap(raw, (raw.width - side) / 2, (raw.height - side) / 2, side, side)
        return Bitmap.createScaledBitmap(square, 256, 256, true)
    }

    // ---------- icons ----------

    private fun fetchIconAsync(id: String, host: String?) {
        if (host == null) return
        val app = applicationContext
        Thread {
            val bmp = Favicon.fetch(host) ?: return@Thread
            val current = Store.load(app).firstOrNull { it.id == id } ?: return@Thread
            if (current.custom) return@Thread
            Store.writePng(Store.iconFile(app, id), bmp)
            BookmarkWidget.refresh(app)
            runOnUiThread { if (!isFinishing) refreshList() }
        }.start()
    }

    private fun refreshIcons() {
        val items = Store.load(this).filter { !it.custom }
        if (items.isEmpty()) return
        Toast.makeText(this, "Fetching icons...", Toast.LENGTH_SHORT).show()
        items.forEach { fetchIconAsync(it.id, hostOf(it.url)) }
    }

    // ---------- browser ----------

    private fun pickBrowser() {
        val pm = packageManager
        val probe = Intent(Intent.ACTION_VIEW, Uri.parse("https://example.com"))
            .addCategory(Intent.CATEGORY_BROWSABLE)
        val found = LinkedHashMap<String, String>()
        for (ri in pm.queryIntentActivities(probe, PackageManager.MATCH_ALL)) {
            found[ri.activityInfo.packageName] = ri.loadLabel(pm).toString()
        }
        val names = mutableListOf("System default")
        val pkgs = mutableListOf<String?>(null)
        for ((p, l) in found) {
            names.add(l)
            pkgs.add(p)
        }
        AlertDialog.Builder(this)
            .setTitle("Open links with")
            .setItems(names.toTypedArray()) { _, which ->
                Store.setBrowser(this, pkgs[which])
                refreshBrowserLabel()
            }
            .show()
    }

    private fun refreshBrowserLabel() {
        val pkg = Store.browser(this)
        browserBtn.text = if (pkg == null) {
            "System default"
        } else {
            try {
                packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
            } catch (e: Exception) {
                pkg
            }
        }
    }

    // ---------- helpers ----------

    private fun hostOf(url: String): String? =
        try { Uri.parse(url).host } catch (e: Exception) { null }

    private fun normalizeUrl(raw: String): String =
        if (raw.contains("://")) raw else "https://$raw"

    private fun dp(n: Int): Int = (n * resources.displayMetrics.density).toInt()

    private fun tv(s: String, sp: Float, bold: Boolean = false): TextView {
        val t = TextView(this)
        t.text = s
        t.textSize = sp
        if (bold) t.setTypeface(t.typeface, Typeface.BOLD)
        return t
    }

    private fun smallButton(label: String, enabled: Boolean, onClick: () -> Unit): Button {
        val b = Button(this, null, android.R.attr.borderlessButtonStyle)
        b.text = label
        b.minWidth = 0
        b.minimumWidth = 0
        b.isEnabled = enabled
        b.setPadding(0, 0, 0, 0)
        b.layoutParams = LinearLayout.LayoutParams(dp(40), dp(44))
        b.setOnClickListener { onClick() }
        return b
    }

    companion object {
        private const val REQ_PICK = 1001
    }
}
