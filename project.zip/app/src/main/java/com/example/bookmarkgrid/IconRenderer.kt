package com.example.bookmarkgrid

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RectF

object IconRenderer {

    /** Builds a rounded square icon for a bookmark. */
    fun render(ctx: Context, b: Bookmark, size: Int): Bitmap {
        val s = size.toFloat()
        val content = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val cc = Canvas(content)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)

        val file = Store.iconFile(ctx, b.id)
        val src = if (file.exists()) BitmapFactory.decodeFile(file.path) else null

        if (src == null) {
            // Placeholder: coloured tile with first letter
            paint.color = colorFor(b.title + b.url)
            cc.drawRect(0f, 0f, s, s, paint)
            paint.color = Color.WHITE
            paint.textSize = s * 0.5f
            paint.textAlign = Paint.Align.CENTER
            paint.isFakeBoldText = true
            val letter = (b.title.firstOrNull() ?: '?').uppercaseChar().toString()
            val y = s / 2f - (paint.descent() + paint.ascent()) / 2f
            cc.drawText(letter, s / 2f, y, paint)
        } else if (b.custom) {
            // User image: full bleed
            cc.drawBitmap(src, null, RectF(0f, 0f, s, s), paint)
        } else {
            // Website icon: white tile with padding
            cc.drawColor(Color.WHITE)
            val pad = s * 0.16f
            cc.drawBitmap(src, null, RectF(pad, pad, s - pad, s - pad), paint)
        }

        // Rounded-corner mask
        val out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val oc = Canvas(out)
        val mp = Paint(Paint.ANTI_ALIAS_FLAG)
        val r = s * 0.24f
        oc.drawRoundRect(RectF(0f, 0f, s, s), r, r, mp)
        mp.xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC_IN)
        oc.drawBitmap(content, 0f, 0f, mp)
        return out
    }

    private fun colorFor(seed: String): Int {
        val hue = Math.floorMod(seed.hashCode(), 360).toFloat()
        return Color.HSVToColor(floatArrayOf(hue, 0.55f, 0.65f))
    }
}
