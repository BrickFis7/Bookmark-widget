package com.example.bookmarkgrid

import android.content.Context
import android.graphics.Bitmap
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream

data class Bookmark(
    val id: String,
    var title: String,
    var url: String,
    var custom: Boolean
)

object Store {
    private fun prefs(c: Context) = c.getSharedPreferences("bookmarks", Context.MODE_PRIVATE)

    fun load(c: Context): MutableList<Bookmark> {
        val out = mutableListOf<Bookmark>()
        try {
            val arr = JSONArray(prefs(c).getString("items", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(
                    Bookmark(
                        o.getString("id"),
                        o.getString("title"),
                        o.getString("url"),
                        o.optBoolean("custom", false)
                    )
                )
            }
        } catch (e: Exception) {
            // ignore corrupt data
        }
        return out
    }

    fun save(c: Context, items: List<Bookmark>) {
        val arr = JSONArray()
        for (b in items) {
            arr.put(
                JSONObject()
                    .put("id", b.id)
                    .put("title", b.title)
                    .put("url", b.url)
                    .put("custom", b.custom)
            )
        }
        prefs(c).edit().putString("items", arr.toString()).apply()
    }

    fun browser(c: Context): String? = prefs(c).getString("browser", null)
    fun setBrowser(c: Context, pkg: String?) = prefs(c).edit().putString("browser", pkg).apply()

    fun labels(c: Context): Boolean = prefs(c).getBoolean("labels", false)
    fun setLabels(c: Context, v: Boolean) = prefs(c).edit().putBoolean("labels", v).apply()

    fun iconFile(c: Context, id: String): File {
        val dir = File(c.filesDir, "icons")
        dir.mkdirs()
        return File(dir, "$id.png")
    }

    fun writePng(f: File, bmp: Bitmap) {
        FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
    }
}
