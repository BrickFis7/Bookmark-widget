package com.example.bookmarkgrid

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.net.HttpURLConnection
import java.net.URL

object Favicon {
    /** Downloads the website icon. Call from a background thread. */
    fun fetch(host: String): Bitmap? {
        val sources = listOf(
            "https://www.google.com/s2/favicons?domain=$host&sz=128",
            "https://icons.duckduckgo.com/ip3/$host.ico"
        )
        for (s in sources) {
            try {
                val conn = URL(s).openConnection() as HttpURLConnection
                conn.connectTimeout = 8000
                conn.readTimeout = 8000
                conn.setRequestProperty("User-Agent", "Mozilla/5.0")
                if (conn.responseCode == 200) {
                    val bmp = conn.inputStream.use { BitmapFactory.decodeStream(it) }
                    if (bmp != null) return bmp
                }
            } catch (e: Exception) {
                // try next source
            }
        }
        return null
    }
}
