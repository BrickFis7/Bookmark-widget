package com.example.bookmarkgrid

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast

/** Invisible activity: opens the tapped URL in the chosen browser, then closes. */
class LaunchActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        intent.getStringExtra(EXTRA_URL)?.let { open(this, it) }
        finish()
    }

    companion object {
        const val EXTRA_URL = "url"

        fun open(ctx: Context, url: String) {
            val view = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            val pkg = Store.browser(ctx)
            if (pkg != null) {
                try {
                    ctx.startActivity(Intent(view).setPackage(pkg))
                    return
                } catch (e: Exception) {
                    // browser gone: fall back to default
                }
            }
            try {
                ctx.startActivity(view)
            } catch (e: Exception) {
                Toast.makeText(ctx, "No app can open $url", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
